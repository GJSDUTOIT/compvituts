from cv2 import *
import numpy as np
from math import cos, sin, floor, ceil
