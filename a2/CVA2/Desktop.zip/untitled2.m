A = imread('trump.jpg')
[m,n] = size(A)
cy = (n+1)/2
cx = (m+1)/2
s = 0.6
theta = 315
a = [[1;0;0],[0;1;0],[-cx;-cy;1]]
b = [[(s*cosd(theta));(s*sind(theta));(0)],[(-s * sind(theta));(s * cosd(theta));(0)],[(0);(0);(1)]]
c = [[1;0;0],[0;1;0],[cx;cy;1]]
H = a*b*c
out = applyhomography(A,H)
imwrite(out,'out.jpg')
imshow(out)