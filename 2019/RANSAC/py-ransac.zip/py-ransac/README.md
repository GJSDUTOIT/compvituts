py-ransac
=========

python implemetation of RANSAC algorithm with a line fitting example and a plane fitting example.
